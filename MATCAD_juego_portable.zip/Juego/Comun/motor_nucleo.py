#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Núcleo del motor de partida (sin E/S de pygame ni terminal)."""

from __future__ import annotations

import random
import time
from dataclasses import dataclass, field

from Comun.modelos import Pregunta
from Comun.reglas_partida import (
    ReglasPartida,
    SistemaPuntuacion,
    calcular_puntos_arcade,
    nota_sobre_diez,
    porcentaje_aciertos,
)


@dataclass
class EstadoPartida:
    nombre: str
    reglas: ReglasPartida
    vidas_restantes: int | None
    aciertos: int = 0
    respondidas: int = 0
    puntos_arcade: int = 0
    fallos_por_materia: dict[str, int] = field(default_factory=dict)
    inicio_total: float = field(default_factory=time.monotonic)

    def tiempo_total_restante(self) -> int | None:
        lim = self.reglas.tiempo_total_seg
        if not lim:
            return None
        rest = int(lim - (time.monotonic() - self.inicio_total))
        return max(0, rest)

    def tiempo_transcurrido_seg(self) -> int:
        """Segundos desde el inicio de la partida (tiempo activo sin límite global)."""
        return max(0, int(time.monotonic() - self.inicio_total))

    def debe_continuar(self, total_previsto: int | None) -> bool:
        if self.reglas.tiene_vidas() and (self.vidas_restantes or 0) <= 0:
            return False
        if total_previsto is not None and self.respondidas >= total_previsto:
            return False
        rest = self.tiempo_total_restante()
        if rest is not None and rest <= 0:
            return False
        return True


@dataclass
class ResultadoRespuesta:
    acierto: bool
    respuesta: str = ""
    tiempo_agotado: bool = False


@dataclass
class FeedbackRespuesta:
    mensaje: str
    solucion: str | None = None
    sin_vidas: bool = False


LETRAS_OPCION = ("A", "B", "C", "D")


@dataclass(frozen=True)
class PresentacionOpcionesPregunta:
    """Opciones permutadas y reetiquetadas A–D en pantalla (mapeo al dataset)."""

    filas: tuple[tuple[str, str, str], ...]  # (etiqueta, texto, letra_dataset)

    @classmethod
    def construir(cls, pregunta: Pregunta, *, semilla: int) -> PresentacionOpcionesPregunta:
        originales = [letra for letra in LETRAS_OPCION if pregunta.opciones.get(letra)]
        if len(originales) <= 1:
            filas = tuple(
                (letra, pregunta.opciones.get(letra, ""), letra) for letra in originales
            )
            return cls(filas=filas)
        rng = random.Random(semilla)
        permutadas = list(originales)
        rng.shuffle(permutadas)
        filas = tuple(
            (
                LETRAS_OPCION[i],
                pregunta.opciones.get(permutadas[i], ""),
                permutadas[i],
            )
            for i in range(len(permutadas))
        )
        return cls(filas=filas)

    def letra_dataset(self, etiqueta: str) -> str:
        for etiq, _, origen in self.filas:
            if etiq == etiqueta:
                return origen
        return etiqueta

    def etiqueta_visual(self, letra_dataset: str) -> str | None:
        for etiq, _, origen in self.filas:
            if origen == letra_dataset:
                return etiq
        return None


def semilla_orden_opciones(
    *,
    semilla_base: int,
    numero_turno: int,
    indice_pregunta: int = 0,
) -> int:
    """Semilla estable por turno para permutar opciones en pantalla."""
    return semilla_base + numero_turno * 1_009 + indice_pregunta * 7_919


def presentacion_opciones_pantalla(
    pregunta: Pregunta,
    *,
    semilla: int,
) -> PresentacionOpcionesPregunta:
    """Permuta textos y muestra siempre A, B, C, D en orden vertical."""
    return PresentacionOpcionesPregunta.construir(pregunta, semilla=semilla)


def orden_letras_opciones_pantalla(
    pregunta: Pregunta,
    *,
    semilla: int,
) -> tuple[str, ...]:
    """Etiquetas visuales en pantalla (A–D en orden)."""
    return tuple(etiq for etiq, _, _ in presentacion_opciones_pantalla(pregunta, semilla=semilla).filas)


def marcar_botones_opciones_tras_respuesta(
    botones,
    *,
    presentacion: PresentacionOpcionesPregunta,
    correcta_dataset: str,
    respuesta_dataset: str,
    acierto: bool,
) -> None:
    correcta_vis = presentacion.etiqueta_visual(correcta_dataset)
    respuesta_vis = (
        presentacion.etiqueta_visual(respuesta_dataset) if respuesta_dataset else None
    )
    for boton in botones:
        boton.activo = False
        boton.marcar_correcta = False
        boton.marcar_incorrecta = False
        if correcta_vis and boton.letra == correcta_vis:
            boton.marcar_correcta = True
        elif respuesta_vis and boton.letra == respuesta_vis and not acierto:
            boton.marcar_incorrecta = True


def texto_solucion(
    p: Pregunta,
    presentacion: PresentacionOpcionesPregunta | None = None,
) -> str:
    if p.correcta in LETRAS_OPCION:
        texto = p.opciones.get(p.correcta, "")
        etiqueta = p.correcta
        if presentacion is not None:
            vis = presentacion.etiqueta_visual(p.correcta)
            if vis:
                etiqueta = vis
        return f"Correcta: {etiqueta}) {texto}"
    return "Correcta: (dato no disponible en esta pregunta)"


def linea_estado(
    estado: EstadoPartida,
    progreso: str,
    *,
    segundos_pregunta_restantes: int | None = None,
    vidas_max: int | None = None,
    progreso_puerta: str | None = None,
    progreso_sala: str | None = None,
    mostrar_tiempo_activo: bool = True,
    desafio_bloque_texto: str | None = None,
) -> str:
    from Comun.linea_estado_ui import linea_estado_con_iconos

    return linea_estado_con_iconos(
        estado,
        progreso,
        segundos_pregunta_restantes=segundos_pregunta_restantes,
        vidas_max=vidas_max,
        progreso_puerta=progreso_puerta,
        progreso_sala=progreso_sala,
        mostrar_tiempo_activo=mostrar_tiempo_activo,
        desafio_bloque_texto=desafio_bloque_texto,
    )


def evaluar_respuesta(
    p: Pregunta,
    estado: EstadoPartida,
    resultado: ResultadoRespuesta,
) -> FeedbackRespuesta:
    estado.respondidas += 1
    reglas = estado.reglas

    if reglas.correccion_al_final:
        if resultado.tiempo_agotado or not resultado.acierto:
            estado.fallos_por_materia[p.materia] = estado.fallos_por_materia.get(p.materia, 0) + 1
        else:
            estado.aciertos += 1
        return FeedbackRespuesta(mensaje="Respuesta registrada.")

    if resultado.tiempo_agotado:
        if reglas.tiene_vidas():
            estado.vidas_restantes = (estado.vidas_restantes or 0) - 1
        estado.fallos_por_materia[p.materia] = estado.fallos_por_materia.get(p.materia, 0) + 1
        solucion = texto_solucion(p) if reglas.mostrar_solucion_tras_fallo else None
        return FeedbackRespuesta(
            mensaje="Tiempo agotado — cuenta como fallo",
            solucion=solucion,
            sin_vidas=reglas.tiene_vidas() and (estado.vidas_restantes or 0) <= 0,
        )

    if resultado.acierto:
        estado.aciertos += 1
        if reglas.sistema_puntuacion == SistemaPuntuacion.ARCADE:
            delta = calcular_puntos_arcade(p.dificultad, True)
            estado.puntos_arcade += delta
            return FeedbackRespuesta(mensaje=f"Correcto (+{delta} puntos)")
        return FeedbackRespuesta(mensaje="Correcto")

    if reglas.tiene_vidas():
        estado.vidas_restantes = (estado.vidas_restantes or 0) - 1
    estado.fallos_por_materia[p.materia] = estado.fallos_por_materia.get(p.materia, 0) + 1
    if reglas.sistema_puntuacion == SistemaPuntuacion.ARCADE:
        delta = calcular_puntos_arcade(p.dificultad, False)
        estado.puntos_arcade += delta
        mensaje = f"Incorrecto ({delta} puntos)"
    else:
        mensaje = "Incorrecto"
    solucion = texto_solucion(p) if reglas.mostrar_solucion_tras_fallo else None
    return FeedbackRespuesta(
        mensaje=mensaje,
        solucion=solucion,
        sin_vidas=reglas.tiene_vidas() and (estado.vidas_restantes or 0) <= 0,
    )
