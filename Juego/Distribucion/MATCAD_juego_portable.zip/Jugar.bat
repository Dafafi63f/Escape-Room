@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>&1
if %errorlevel%==0 (
    py -3 Juego\juego_grafico.py
    goto :fin
)

where python >nul 2>&1
if %errorlevel%==0 (
    python Juego\juego_grafico.py
    goto :fin
)

echo.
echo No se encontro Python en el PATH.
echo Instala Python 3.10+ y ejecuta:
echo   pip install -r Juego\requirements.txt
echo   python Juego\juego_grafico.py
echo.
echo Lee LEEME.txt en esta carpeta.
echo.

:fin
if errorlevel 1 pause
