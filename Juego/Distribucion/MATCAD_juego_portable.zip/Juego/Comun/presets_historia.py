#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Catálogo y resolución de partidas del modo historia."""

from __future__ import annotations

from collections.abc import Callable
import json
from dataclasses import dataclass
from pathlib import Path

from Comun.config_historia import (
    MATERIAS_POR_SEMESTRE,
    ConfigPresetHistoria,
    ESTRATEGIA_MATERIAS_DEFECTO,
    OpcionPreset,
    curso_semestre_desde_valores,
    defectos_config,
    estrategia_materias_desde_config,
    opciones_config_historia,
    usar_analisis_historico_desde_config,
    max_materias_ambito,
    parse_opciones,
    tipos_desde_enfoque,
    tiempo_total_seg_desde_config,
    validar_config,
)
from Comun.generador_examen_historia import PerfilPedagogico
from Comun.politica_reglas import (
    ContextoPartida,
    PoliticaReglas,
    politica_escape,
    politica_resistencia,
    politica_historia_reto,
    politica_historia_simulacro,
    validar_reglas,
)
from Comun.reglas_partida import ReglasPartida


ORDEN_PREGUNTAS_VALIDOS = frozenset({
    "aleatorio",
    "dificultad",
    "materia",
    "plantilla",
    "variar",
})


def resolver_orden_preguntas(
    preset: PresetHistoria,
    cfg: ConfigPresetHistoria | None = None,
) -> str:
    """Orden explícito de preguntas en partida (independiente del azar de contenido)."""
    from Comun.modos_diarios import es_id_examen_fijo, orden_preguntas_examen_fijo

    if cfg is not None and es_id_examen_fijo(preset.id):
        return orden_preguntas_examen_fijo(cfg)
    raw = preset.orden_preguntas
    if raw:
        if raw not in ORDEN_PREGUNTAS_VALIDOS:
            raise ValueError(
                f"orden_preguntas inválido en {preset.id!r}: {raw!r} "
                f"(use: {', '.join(sorted(ORDEN_PREGUNTAS_VALIDOS))})."
            )
        return raw
    if preset.variar_orden_cada_partida:
        return "variar"
    if preset.orden_preguntas_por_materia:
        return "materia"
    if preset.orden_preguntas_por_dificultad:
        return "dificultad"
    return "aleatorio"


@dataclass(frozen=True)
class PresetHistoria:
    """Plantilla de partida con reglas fijas y opciones acotadas."""

    id: str
    nombre: str
    descripcion: str
    categoria: str
    orden: int
    perfil: str
    contexto_reglas: str
    seleccion_determinista: bool
    n_materias: int | None
    curso_filtro: str | None
    semestre_filtro: str | None
    grupo_filtro: str | None
    preguntas_por_materia: int | None
    opciones: tuple[OpcionPreset, ...]
    tiempo_por_pregunta_seg: int | None = None
    tiempo_total_seg: int | None = None
    orden_por_historico: str | None = None
    orden_preguntas: str | None = None
    orden_preguntas_por_dificultad: bool = False
    orden_preguntas_por_materia: bool = False
    variar_orden_cada_partida: bool = False
    exigir_balance_completo: bool = False
    usa_analisis_historico: bool = True
    usar_plantillas_materia: bool = False
    solo_atajo: bool = False

    def contexto(self) -> ContextoPartida:
        return ContextoPartida(self.contexto_reglas)

    def tiene_opciones(self) -> bool:
        return bool(self.opciones)


def _parse_preguntas_por_materia(raw: int | None) -> int | None:
    if raw is None:
        return None
    n = int(raw)
    if n <= 0:
        raise ValueError(f"preguntas_por_materia debe ser positivo: {n!r}")
    return n

_IDS_PRESET_REPASOS: frozenset[str] = frozenset({
    "repaso",
    "repaso_area",
})

_IDS_PRESET_SIMULACROS: frozenset[str] = frozenset({
    "simulacro",
    "examen_asignatura",
    "examen_fijo",
})

# IDs retirados del catálogo activo (documentación, tests y tabla en Data/README.md).
PRESETS_HISTORIA_RETIRADOS = frozenset({
    "examen_dia_historia",
    "examen_aleatorio_historia",
    "repaso_express",
    "repaso_historico",
    "repaso_integral",
    "vuelta_grado",
    "semana_examenes",
    "simulacro_curso",
})

NUM_MODOS_HISTORIA_CARRUSEL = 5

_CONTEXTOS_ESPECIALES = frozenset({
    ContextoPartida.ESCAPE.value,
    ContextoPartida.RESISTENCIA.value,
})


def _es_preset_historia(preset: PresetHistoria) -> bool:
    return preset.contexto_reglas.startswith("historia_")


def _es_preset_especial(preset: PresetHistoria) -> bool:
    return preset.contexto_reglas in _CONTEXTOS_ESPECIALES


def _grupo_catalogo_historia(preset_id: str) -> int:
    """Orden de bloques en el carrusel: repasos, luego simulacros, luego el resto."""
    if preset_id in _IDS_PRESET_REPASOS:
        return 1
    if preset_id in _IDS_PRESET_SIMULACROS:
        return 2
    return 3


def _clave_orden_catalogo(preset: PresetHistoria) -> tuple[int, int, int, str]:
    """Diarios primero; dentro del catálogo, repasos y simulacros en bloques."""
    from Comun.modos_diarios import prioridad_orden_preset

    return (
        prioridad_orden_preset(preset.id),
        _grupo_catalogo_historia(preset.id),
        preset.orden,
        preset.nombre,
    )


def _cargar_presets_desde_json(
    path: Path,
    *,
    clave_orden: Callable[[PresetHistoria], tuple],
    catalogo_historia: bool = False,
) -> list[PresetHistoria]:
    if not path.exists():
        raise FileNotFoundError(f"No se encontró el catálogo: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON inválido en {path}: {e}") from e
    items = data.get("presets")
    if not isinstance(items, list) or not items:
        raise ValueError(f"El catálogo {path} no contiene presets.")
    presets = [_parse_preset(x, catalogo_historia=catalogo_historia) for x in items]
    presets.sort(key=clave_orden)
    ids = [p.id for p in presets]
    if len(ids) != len(set(ids)):
        raise ValueError(f"Hay ids duplicados en {path.name}")
    return presets


def _cargar_presets_historia_archivo(path: Path) -> list[PresetHistoria]:
    return _cargar_presets_desde_json(
        path,
        clave_orden=_clave_orden_catalogo,
        catalogo_historia=True,
    )


def _cargar_todos_presets(path: Path | None = None) -> list[PresetHistoria]:
    from Comun.rutas import resolver_presets

    ruta = path or resolver_presets()
    return _cargar_presets_historia_archivo(ruta)


def cargar_presets_historia(path: Path | None = None) -> list[PresetHistoria]:
    """Catálogo del carrusel (modos historia visibles, sin atajos ni especiales)."""
    visibles = [
        p
        for p in _cargar_todos_presets(path)
        if _es_preset_historia(p) and not p.solo_atajo
    ]
    visibles.sort(key=_clave_orden_catalogo)
    if len(visibles) != NUM_MODOS_HISTORIA_CARRUSEL:
        ids = [p.id for p in visibles]
        raise ValueError(
            f"El carrusel de historia debe tener exactamente {NUM_MODOS_HISTORIA_CARRUSEL} "
            f"modos visibles; hay {len(visibles)}: {ids}"
        )
    return visibles


def cargar_presets_especiales(path: Path | None = None) -> list[PresetHistoria]:
    from Comun.modos_diarios import prioridad_orden_preset

    especiales = [p for p in _cargar_todos_presets(path) if _es_preset_especial(p)]
    especiales.sort(
        key=lambda preset: (
            prioridad_orden_preset(preset.id),
            preset.orden,
            preset.nombre,
        )
    )
    return especiales


def buscar_preset(preset_id: str) -> PresetHistoria:
    """Busca un preset en el catálogo unificado."""
    for preset in _cargar_todos_presets():
        if preset.id == preset_id:
            return preset
    raise KeyError(f"Preset no encontrado: {preset_id!r}")


def _parse_preset(item: dict, *, catalogo_historia: bool = False) -> PresetHistoria:
    for campo in ("id", "nombre", "descripcion", "perfil", "contexto_reglas"):
        if not item.get(campo):
            raise ValueError(f"Preset sin campo obligatorio {campo!r}: {item!r}")
    contexto = item["contexto_reglas"]
    if contexto not in {
        c.value
        for c in ContextoPartida
        if c.name.startswith("HISTORIA_")
        or c in (ContextoPartida.RESISTENCIA, ContextoPartida.ESCAPE)
    }:
        raise ValueError(f"contexto_reglas desconocido: {contexto!r}")
    # Por defecto el catálogo historia usa MatCAD; un preset puede desactivarlo en JSON.
    usa_historico = bool(item.get("usa_analisis_historico", catalogo_historia))
    return PresetHistoria(
        id=str(item["id"]),
        nombre=str(item["nombre"]),
        descripcion=str(item["descripcion"]),
        categoria=str(item.get("categoria") or "General"),
        orden=int(item.get("orden", 999)),
        perfil=str(item["perfil"]),
        contexto_reglas=contexto,
        seleccion_determinista=bool(item.get("seleccion_determinista", False)),
        n_materias=item.get("n_materias"),
        curso_filtro=item.get("curso_filtro"),
        semestre_filtro=item.get("semestre_filtro"),
        grupo_filtro=item.get("grupo_filtro"),
        preguntas_por_materia=_parse_preguntas_por_materia(item.get("preguntas_por_materia")),
        opciones=parse_opciones(item.get("opciones")),
        tiempo_por_pregunta_seg=item.get("tiempo_por_pregunta_seg"),
        tiempo_total_seg=item.get("tiempo_total_seg"),
        orden_por_historico=item.get("orden_por_historico"),
        orden_preguntas=item.get("orden_preguntas"),
        orden_preguntas_por_dificultad=bool(item.get("orden_preguntas_por_dificultad", False)),
        orden_preguntas_por_materia=bool(item.get("orden_preguntas_por_materia", False)),
        variar_orden_cada_partida=bool(item.get("variar_orden_cada_partida", False)),
        exigir_balance_completo=bool(item.get("exigir_balance_completo", False)),
        usa_analisis_historico=usa_historico,
        usar_plantillas_materia=bool(item.get("usar_plantillas_materia", False)),
        solo_atajo=bool(item.get("solo_atajo", False)),
    )


def config_defecto(
    preset: PresetHistoria,
    *,
    materias_meta: dict[str, dict[str, str]],
    materias_orden: list[str],
) -> ConfigPresetHistoria:
    return defectos_config(
        opciones_config_historia(preset),
        materias_meta=materias_meta,
        materias_orden=materias_orden,
    )


def politica_desde_preset(
    preset: PresetHistoria,
    config: ConfigPresetHistoria | None = None,
) -> PoliticaReglas:
    if preset.contexto_reglas == ContextoPartida.HISTORIA_RETO.value:
        base = politica_historia_reto()
    elif preset.contexto_reglas == ContextoPartida.RESISTENCIA.value:
        base = politica_resistencia()
    elif preset.contexto_reglas == ContextoPartida.ESCAPE.value:
        base = politica_escape()
    else:
        base = politica_historia_simulacro()
    if preset.contexto_reglas == ContextoPartida.ESCAPE.value:
        reglas = base.reglas
    else:
        reglas = _reglas_con_tiempo(base.reglas, preset, config)
    return PoliticaReglas(
        contexto=preset.contexto(),
        reglas=reglas,
        eleccion_jugador=bool(preset.opciones),
        mensaje=f"{preset.nombre}: {preset.descripcion}",
    )


def aplicar_preset(
    preset: PresetHistoria,
    config: ConfigPresetHistoria | None = None,
) -> ReglasPartida:
    politica = politica_desde_preset(preset, config)
    return validar_reglas(politica.reglas, politica.contexto)


def _reglas_con_tiempo(
    base: ReglasPartida,
    preset: PresetHistoria,
    config: ConfigPresetHistoria | None,
) -> ReglasPartida:
    tiempo_preg = preset.tiempo_por_pregunta_seg
    tiempo_tot = preset.tiempo_total_seg
    if config is not None:
        t_cfg = tiempo_total_seg_desde_config(config)
        if t_cfg is not None:
            tiempo_tot = t_cfg
    if not tiempo_preg and not tiempo_tot:
        return base
    return ReglasPartida(
        vidas=base.vidas,
        tiempo_por_pregunta_seg=tiempo_preg,
        tiempo_total_seg=tiempo_tot,
        sistema_puntuacion=base.sistema_puntuacion,
        mostrar_solucion_tras_fallo=base.mostrar_solucion_tras_fallo,
        mostrar_aciertos_en_curso=base.mostrar_aciertos_en_curso,
        correccion_al_final=base.correccion_al_final,
        dificultad_progresiva=base.dificultad_progresiva,
    )


def perfil_desde_preset(preset: PresetHistoria) -> PerfilPedagogico:
    try:
        return PerfilPedagogico(preset.perfil)
    except ValueError as e:
        raise ValueError(f"Perfil desconocido en preset {preset.id!r}: {preset.perfil!r}") from e


_ESTRATEGIA_MATERIAS: dict[str, tuple[PerfilPedagogico, bool]] = {
    "curricular": (PerfilPedagogico.BALANCEADO, True),
    "debilidades": (PerfilPedagogico.REFUERZO, False),
    "fortalezas": (PerfilPedagogico.DESAFIO, False),
    "equilibrado": (PerfilPedagogico.BALANCEADO, False),
    "sin_historico": (PerfilPedagogico.BALANCEADO, False),
}


def _resolver_perfil_y_seleccion(
    preset: PresetHistoria,
    cfg: ConfigPresetHistoria,
) -> tuple[PerfilPedagogico, bool]:
    if not preset.usa_analisis_historico:
        return perfil_desde_preset(preset), preset.seleccion_determinista
    estrategia = estrategia_materias_desde_config(cfg) or ESTRATEGIA_MATERIAS_DEFECTO
    if estrategia in _ESTRATEGIA_MATERIAS:
        perfil, seleccion_det = _ESTRATEGIA_MATERIAS[estrategia]
        return perfil, seleccion_det
    return perfil_desde_preset(preset), preset.seleccion_determinista


def semilla_desde_preset(
    preset: PresetHistoria,
    cfg: ConfigPresetHistoria | None = None,
) -> int | None:
    from Comun.modos_diarios import es_id_examen_fijo
    from Comun.semillas import resolver_semillas_partida

    if cfg is not None and es_id_examen_fijo(preset.id):
        semilla = resolver_semillas_partida(
            preset_id=preset.id,
            cfg=cfg,
            orden_preguntas=resolver_orden_preguntas(preset, cfg),
        )
        return semilla
    return None


def contenido_examen_estable(
    preset: PresetHistoria,
    *,
    cfg: ConfigPresetHistoria | None = None,
    semilla: int | None = None,
) -> bool:
    """True si las preguntas no cambian entre entradas (p. ej. examen del día).

    Solo entonces tiene sentido ``variar_orden_cada_partida``: una sola fuente de azar.
    """
    from Comun.modos_diarios import contenido_estable_examen_fijo, es_id_examen_fijo

    if semilla is not None:
        return True
    if cfg is not None and es_id_examen_fijo(preset.id):
        return contenido_estable_examen_fijo(cfg)
    return False


def argumentos_generador(
    preset: PresetHistoria,
    config: ConfigPresetHistoria | None = None,
    *,
    materias_meta: dict[str, dict[str, str]] | None = None,
) -> dict:
    """Parámetros nombrados para ``generar_examen``."""
    cfg = config or ConfigPresetHistoria()
    curso, semestre = curso_semestre_desde_valores(cfg.valores)
    curso = curso or preset.curso_filtro
    semestre = semestre or preset.semestre_filtro
    grupo = cfg.get_str("grupo") or preset.grupo_filtro
    materia = cfg.get_str("materia")

    n_materias = preset.n_materias
    if any(o.id == "n_materias" for o in preset.opciones):
        for op in preset.opciones:
            if op.id == "n_materias":
                n_materias = cfg.get_int("n_materias", int(op.defecto or MATERIAS_POR_SEMESTRE))
                break

    tipos_permitidos = tipos_desde_enfoque(cfg.get_str("enfoque"))

    usar_todas = (
        preset.n_materias is None
        and "n_materias" not in {o.id for o in preset.opciones}
    )
    if materia:
        usar_todas = False
        n_materias = 1

    if usar_todas:
        estrategia = estrategia_materias_desde_config(cfg) or ESTRATEGIA_MATERIAS_DEFECTO
        if estrategia in _ESTRATEGIA_MATERIAS:
            perfil, _ = _ESTRATEGIA_MATERIAS[estrategia]
        else:
            perfil = PerfilPedagogico.POR_CURSO
        seleccion_det = True
    else:
        perfil, seleccion_det = _resolver_perfil_y_seleccion(preset, cfg)

    if not usar_todas and n_materias is not None and materias_meta is not None:
        tope = max_materias_ambito(
            materias_meta, curso=curso, semestre=semestre, grupo=grupo
        )
        if tope > 0:
            n_materias = min(n_materias, tope)

    n_preguntas = None
    for op in preset.opciones:
        if op.id == "n_preguntas":
            n_preguntas = cfg.get_int("n_preguntas", int(op.defecto or 12))
            break

    return {
        "perfil": perfil,
        "n_materias": n_materias if n_materias is not None else MATERIAS_POR_SEMESTRE,
        "curso_filtro": curso,
        "semestre_filtro": semestre,
        "grupo_filtro": grupo,
        "materia_fija": materia,
        "preguntas_por_materia": preset.preguntas_por_materia,
        "tipos_permitidos": tipos_permitidos,
        "usar_todas_materias_ambito": usar_todas,
        "seleccion_determinista": seleccion_det,
        "orden_preguntas": resolver_orden_preguntas(preset, cfg),
        "exigir_balance_completo": preset.exigir_balance_completo,
        "usar_analisis_historico": usar_analisis_historico_desde_config(preset, cfg),
        "usar_plantillas_materia": preset.usar_plantillas_materia,
        "n_preguntas": n_preguntas,
    }
